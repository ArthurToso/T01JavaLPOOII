rootProject.name = "base"

include("code-generator-model")
