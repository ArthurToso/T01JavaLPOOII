/**
 * Demo domain model.
 */

package example.domain;
