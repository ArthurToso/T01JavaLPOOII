/**
 * Internal classes for test discovery within the JUnit Jupiter test engine.
 * Contains resolvers for Java elements.
 */

package org.junit.jupiter.engine.discovery;
